Action()
{

	lr_start_transaction("Login");

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("lgout");

	lr_end_transaction("lgout",LR_AUTO);

	return 0;
}